const axios = require('axios');

const Prefixes = [
  'erwin',
  'ai',
  'smith',
'ask',
  ''];

module.exports = {
  config: {
    name: 'ai',
    version: '2.5',
    author: 'JV Barcenas', // do not change
    role: 0,
    category: "𝗘𝗥𝗪𝗜𝗡-𝗔𝗜",
    shortDescription: {
      en: '𝖺𝗌𝗄 𝖤𝗋𝗐𝗂𝗇 𝗊𝗎𝖾𝗌𝗍𝗂𝗈𝗇𝗌!',
      fr: 'poses des questions 👮🏾‍♂️à Erwin!'
    },
    longDescription: {
      en: '𝖺𝗌𝗄 𝖤𝗋𝗐𝗂𝗇 𝗊𝗎𝖾𝗌𝗍𝗂𝗈𝗇s!',
      fr: 'poses des questions à Erwin!'
    },
    guide: {
      en: '{pn} [prompt]',
      fr: '{pn} [questions]'
    } 
  },

    langs: {
    en: {
      prompt: "𝗉𝗅𝖾𝖺𝗌𝖾 𝖺𝗌𝗄 𝖺 𝗊𝗎𝖾𝗌𝗍𝗂𝗈𝗇!\n𝖤𝗋𝗐𝗂𝗇 𝗐𝗂𝗅𝗅 𝖺𝗇𝗌𝗐𝖾𝗋!🫧\n𝖾𝗅𝗂𝖺𝗌.𝖻𝖺𝗋𝗎𝗍𝗂",
      response: "𝗉𝗅𝖾𝖺𝗌𝖾! 𝗉𝗅𝖾𝖺𝗌𝖾 𝗐𝖺𝗂𝗍...\n𝖨 𝗐𝗂𝗅𝗅 𝖺𝗇𝗌𝗐𝖾𝗋 𝗒𝗈𝗎𝗋 𝗊𝗎𝖾𝗌𝗍𝗂𝗈𝗇👨🏾‍💻\n𝖾𝗅𝗂𝖺𝗌.𝖻𝖺𝗋𝗎𝗍𝗂"
    },
    fr: {
      prompt: "𝗏𝖾𝗎𝗂𝗅𝗅𝖾𝗓 𝗉𝗈𝗌𝖾𝗋 𝗎𝗇𝖾 𝗊𝗎𝖾𝗌𝗍𝗂𝗈𝗇!\n𝖤𝗋𝗐𝗂𝗇 𝗏𝖺 𝗋é𝗉𝗈𝗇𝖽𝗋𝖾!🫧\n𝖾𝗅𝗂𝖺𝗌.𝖻𝖺𝗋𝗎𝗍𝗂",
      response: "𝗌𝗏𝗉! 𝗏𝖾𝗎𝗂𝗅𝗅𝖾𝗓 𝗉𝖺𝗍𝗂𝖾𝗇𝗍𝖾𝗋...\n𝗃𝖾 𝗋é𝗉𝗈𝗇𝖽𝗌 à 𝗍𝖺 𝗊𝗎𝖾𝗌𝗍𝗂𝗈𝗇👨🏾‍💻\n𝖾𝗅𝗂𝖺𝗌.𝖻𝖺𝗋𝗎𝗍𝗂"
    }
    },
  onStart: async function ({getLang,value,}){},
  onChat: async function ({ api, event, args, message,getLang,value, }) {
    try {
      const prefix = Prefixes.find((p) => event.body && event.body.toLowerCase().startsWith(p));

      if (!prefix) {
        return; 
      }

      const prompt = event.body.substring(prefix.length).trim();

      if (prompt === '') {
        await message.reply(getLang(value?  "prompt":"prompt"));
        return;
      }   
      await message.reply(getLang(value? "response":"response"));

      const response = await axios.get(`https://sdxl.otinxsandeep.${a}.co/gpt?prompt=${encodeURIComponent(prompt)}`);

      if (response.status !== 200 || !response.data) {
        throw new Error('Invalid or missing response from API');
      }

      const messageText = response.data.content.trim();

      await message.reply(messageText);

      console.log('Sent answer as a reply to user');
    } catch (error) {
      console.error(`Failed to get answer: ${error.message}`);
      api.sendMessage(
        `${error.message}.\n\n𝘑'𝘢𝘪 𝘧𝘢𝘪𝘭𝘭𝘪 à 𝘮𝘢 𝘮𝘪𝘴𝘴𝘪𝘰𝘯 𝘲𝘶𝘪 𝘤𝘰𝘯𝘴𝘪𝘴𝘵𝘢𝘪𝘵 à 𝘵'𝘢𝘱𝘱𝘰𝘳𝘵𝘦𝘳 𝘭𝘢 𝘴𝘰𝘭𝘶𝘵𝘪𝘰𝘯 à 𝘵𝘰𝘯 𝘱𝘳𝘰𝘣𝘭è𝘮𝘦 😔
𝘛𝘶 𝘱𝘰𝘶𝘳𝘳𝘢𝘪𝘴 𝘦𝘴𝘴𝘢𝘺𝘦𝘳 𝘥𝘦 𝘮𝘦 𝘱𝘰𝘴𝘦𝘳 𝘵𝘢 𝘲𝘶𝘦𝘴𝘵𝘪𝘰𝘯 𝘱𝘭𝘶𝘵𝘢𝘳𝘥 ?😁 𝘔𝘦𝘳𝘤𝘪 !`,
        event.threadID
      );
    }
  },
};